# Basic_Python_Notebooks
This repository contains the notebooks for basic python
